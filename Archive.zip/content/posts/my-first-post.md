---
title: "My First Post"
date: 2020-04-29T00:21:12+08:00
draft: true
---

In this blog I aspire to detail my journey in adopting AWS Amplify, Cognito, AppSync and DynamoDb.
But first let me stick my dick in this toaster.

We first need to define the required permissions to provision EKS clusters (this includes the ability to pass account roles to the EKS service from Amazon)

{{< youtube f87M_p91Tg0 >}}
