---
title: "{{ replace .TranslationBaseName '-' ' ' | title }}"
description: ""
date: "{{ .Date }}"
thumbnail: ""
categories:
  - ""
tags:
  - ""
---
